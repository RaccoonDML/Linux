/*
 * my_stack的实现文件
 * 如果采用C++的实现，那也可以把此文件名改为.cpp
 * 但是记住g++才是编译C++的编译器
 *
 */
#include <stdio.h>
#include <stdlib.h>
#define maxn 6

int top=-1; 
int sta[maxn];

int stack_is_full(){
	return top==maxn-1;
}
int stack_is_empty(){
	return top==-1;	
}
void stack_push(int x){
	sta[++top]=x;
}
int stack_pop(){
	return sta[top--];
}
int stack_capacity(){
	return maxn-1;
}
int stack_size(){
	return top;
}
